const App = () => {
  return (
    <div>
      <h1 className='text-5xl'>APP</h1>
    </div>
  );
};

export default App;
